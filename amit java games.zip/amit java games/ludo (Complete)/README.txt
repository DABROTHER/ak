Pixel of each block = 39*39
size of board    =  600*600